This is the repository of "Leveraging Neo4j Streams" series on Medium:

* [How to leverage Neo4j Streams and build a just-in-time data warehouse with Apache Kafka](https://medium.com/free-code-camp/how-to-leverage-neo4j-streams-and-build-a-just-in-time-data-warehouse-64adf290f093)
* [How to ingest data into Neo4j from a Kafka stream](https://medium.com/free-code-camp/how-to-ingest-data-into-neo4j-from-a-kafka-stream-a34f574f5655)
* [How to produce and consume Kafka data streams directly via Cypher with Streams Procedures](https://medium.com/free-code-camp/how-to-produce-and-consume-data-streams-directly-via-cypher-with-streams-procedures-52cbc5f543f1)
